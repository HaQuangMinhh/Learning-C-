﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.Design;

namespace StudentEnrollmentSystem
{
    internal class Program
    {
        public static List<Course> Courses = new List<Course>()
        {
            new Course("CSE205", "Mang May Tinh"),
            new Course("CSE201", "Coding"),
            new Course("CSE204", "nhap mon lap trinh")
        };
        public static List<Student> Students = new List<Student>() 
        { 
            new Student("1" , "Nguyen Manh Cuong"),
            new Student("2" , "Nguyen Anh"),
            new Student("3" , "Nguyen Ha"),
        };
        
        static void Main(string[] args)
        {
            // Build a system to manage student enrollment in courses

            var canContinue = true;
            while (canContinue) {
                Console.WriteLine("Student : ");
                Console.WriteLine("1. Add a new student");
                Console.WriteLine("2. Remove all student by Student ID");
                Console.WriteLine("3. List all students with their details");
                Console.WriteLine("=======================================================");
                Console.WriteLine("Course : ");
                Console.WriteLine("4. Add a new Course");
                Console.WriteLine("5. Remove a course by Course Code");
                Console.WriteLine("6. List all courses with their details");
                Console.WriteLine("7. Exit");

                var choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        AddStudent();
                        break;
                    case "2":
                        RemoveStudent();
                        Console.WriteLine("=========================================================");
                        break;
                    case "3":
                        ShowAllSudents();
                        Console.WriteLine("=========================================================");
                        break;
                    case "4":
                        AddCourse();
                        break;
                    case "5":
                        RemoveCourse();
                        break;
                    case "6":
                        ShowAllCourses();
                        break;
                    case "7":
                        canContinue = false;
                        break;


                        
                    default:
                        Console.WriteLine("=========================================================");
                        Console.WriteLine("User input carefully");
                        break; 
                }
            }


        }
        public static void CourseEnrollment(string studentId , string courseCode) {
            Student student = null  ; // Chứa rỗng null và store value 
            var studentFound = false; 

            foreach ( var s in Students ) {
                if ( s.Id == studentId ) {
                    student = s;
                    studentFound = true;
                    break;                 
                }
            }

            // muốn bắt giá trị 
            if ( !studentFound  ) { 
                Console.WriteLine("Student not found");
                return; 
            }


            Course course = null ; // Chứa rỗng null và store value 
            var courseFound = false;

            foreach (var c in Courses )
            {
                if ( c.CourseCode == courseCode)
                {
                    course = c;
                    studentFound = true;
                    break;
                }
            }

            // muốn bắt giá trị 
            if ( !courseFound )
            {
                Console.WriteLine("Course not found");
                return;
            }

            // Course and student - found 
            student.Courses.Add(course);
            course.Students.Add(student);

            // function nhận vào all ID ==> show ra all môn học 
            // create case 

            // function các học sinh rút môn - nhận vào studentId, CourseCode 

            // function xem danh sách môn - nhập courseCode show ra danh sách sinh viên
             





        }


        // Hàm Student
        #region
        //====================================================== Student 
        public static void AddStudent()
        {
            Console.WriteLine("Student id : ");
            var id = Console.ReadLine();
            Console.WriteLine("Student name: ");
            var name = Console.ReadLine();

            Students.Add(new Student( id , name  ) );
            Console.WriteLine("Add students successfully");
            Console.WriteLine("=========================================================");
        }

        public static void RemoveStudent()
        {
            Console.WriteLine("You want to delete student: ");
            var studentId = Console.ReadLine();

            var remove = Students.RemoveAll( x => x.Id == studentId );

            if (remove > 0)
            {
                Console.WriteLine("You deleted successfully");
            }
            else { 
                Console.WriteLine("Don't have this student");
            }
        }

        public static void ShowAllSudents()
        {
            if (Students.Count > 0)
            {
                Console.WriteLine("All students below : ");
                foreach (var eachStudent in Students)
                {
                    Console.WriteLine($"Id : {eachStudent.Id} , Name: {eachStudent.Name} ");
                }
            }
            else { 
                Console.WriteLine("Don't have any student");
            }
        
        }
        #endregion 


        // Hàm Course
        #region
        //========================================================== Course 
        public static void AddCourse()
        {
            Console.WriteLine("Course Id is: ");
            var courseCode = Console.ReadLine();
            Console.WriteLine("Course Name is: ");
            var CourseName = Console.ReadLine();

            Courses.Add(new Course(courseCode, CourseName));
            Console.WriteLine("Add course successfully");
            Console.WriteLine("=========================================================");
        }

        public static void RemoveCourse()
        {
            Console.WriteLine("You want to delete course: ");
            var removeCourseCode = Console.ReadLine();

            var remove = Courses.RemoveAll(x => x.CourseCode == removeCourseCode);

            if (remove > 0)
            {
                Console.WriteLine("You deleted successfully");
            }
            else
            {
                Console.WriteLine("You should check students' number");
            }
            Console.WriteLine("=========================================================");
        }

        public static void ShowAllCourses()
        {
            if (Courses.Count > 0)
            {
                Console.WriteLine("All Courses below : ");
                foreach (var eachCourse in Courses)
                {
                    Console.WriteLine($"Course Code: {eachCourse.CourseCode}  Course Name: {eachCourse.CourseName}");
                }
            }
            else
            {
                Console.WriteLine("Don't have any course");
            }
            Console.WriteLine("=========================================================");
        }
        #endregion



    }
}
