﻿using System.ComponentModel;

namespace StudentEnrollmentSystemCourses
{
    internal class Program
    {
        public static List<Course> Courses = new List<Course>();
        static void Main(string[] args)
        {
            var canContinue = true;

            while (canContinue) {
                Console.WriteLine("1. Add a new Course");
                Console.WriteLine("2. Remove a course by Course Code");
                Console.WriteLine("3. List all courses with their details");
                Console.WriteLine("4. Exit");

                var choice = Console.ReadLine();

                switch (choice) {
                    case "1":
                        AddCourse();
                        break;
                    case "2":
                        RemoveCourse();
                        break;
                    case "3":
                        ShowAllCourses();
                        break;

                    case "4":
                        return; 
                        
                }
            }

        }

        public static void AddCourse()
        { 
            Console.WriteLine("Course Id is: ");
            var courseCode = Console.ReadLine();
            Console.WriteLine("Course Name is: ");
            var CourseName = Console.ReadLine();

            Courses.Add(new Course( courseCode , CourseName ));
            Console.WriteLine("Add course successfully");
            Console.WriteLine("=========================================================");
        }

        public static void RemoveCourse()
        {
            Console.WriteLine("You want to delete course: ");
            var removeCourseCode = Console.ReadLine();

            var remove = Courses.RemoveAll(x => x.CourseCode == removeCourseCode );

            if (remove > 0)
            {
                Console.WriteLine("You deleted successfully");
            }
            else
            {
                Console.WriteLine("You should check students' number");
            }
            Console.WriteLine("=========================================================");
        }

        public static void ShowAllCourses()
        {
            if (Courses.Count > 0)
            {
                Console.WriteLine("All Courses below : ");
                foreach (var eachCourse in Courses )
                {
                    Console.WriteLine($"Course Code: {eachCourse.CourseCode}  Course Name: {eachCourse.CourseName}");
                }
            }
            else
            {
                Console.WriteLine("Don't have any course");
            }
            Console.WriteLine("=========================================================");
        }


    }




    public class Course
    {
        public String CourseCode { get; set; }
        public String CourseName { get; set; }
        public int Credits { get; set; }
        public List<Course> Courses { get; set; } = new List<Course>();

        public Course(string courseCode , string courseName )
        {
            CourseCode = courseCode;
            CourseName = courseName;
        }
    }
}
