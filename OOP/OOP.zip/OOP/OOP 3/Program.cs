﻿namespace OOP_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Build a system to manage student enrollment in courses
            var students = new List<Student>();
            
    // 1. Manage Students : 
    // Add a new student 
            Console.WriteLine("Input your name");
            var name = Console.ReadLine(); // nhập tên
            
            // Write Values
            students.Add( new Student("Minh", "1") );
            students.Add( new Student("Tuan", "2") );
            students.Add( new Student("Hoang","3") );
            students.Add( new Student("Kiet", "4") );
            students.Add( new Student("Nhan", "5") );


            // Show
            Console.WriteLine("==========================================================");
            foreach ( var eachStudent in students ) { 
                Console.WriteLine($"Student: {eachStudent.Name} , Id: {eachStudent.Id}");
            }
            Console.WriteLine("==========================================================");

    // Remove a student by Student ID
            //String studentId = "1";
            //students.RemoveAll( student => student.Id == studentId );
           
            //// Show 
            //Console.WriteLine("==========================================================");
            //Console.WriteLine("Students sau khi xoá : ");
            //foreach (var eachStudent in students)
            //{
            //    Console.WriteLine($"Student: {eachStudent.Name} , Id: {eachStudent.Id}");
            //}
            //Console.WriteLine("==========================================================");

   // List all students with their details 
            Console.WriteLine("List all students with their details: ");
            






        }
    }


    public class Student
    { 
        public String Name { get; set; }
        public String Id { get; set; }

        public List<Student> EnrolledCourses { get; set; } = new List<Student>();

        public List<Student> Details { get; set; } = new List<Student>();
    
        public Student(string name , string id ) { 
            Name = name;    
            Id = id;    
        }

        public Student( string name , string id , List<Student> infor ) { 
            Name =name;
            Id =  id; 
            Details  = infor;
        }
    }

    public class  Course 
    {
        public String CourseName { get; set; }
        public String CourseCode { get; set; }
        public int Credits { get; set; }    
        public List <Course> Courses { get; set; } = new List<Course> ();
    }
}
