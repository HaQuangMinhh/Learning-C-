﻿namespace PetCareApp
{
    internal class Program
    {
        static void Main(string[] args)
        {



            var canContinue = true;

            while (canContinue) {

                Console.WriteLine("1.  ");
                Console.WriteLine("2. ");
                Console.WriteLine("3. ");
                Console.WriteLine("4. ");
                Console.WriteLine("5. ");

                Console.WriteLine("8. Exit");

                var choice = Console.ReadLine();
                switch (choice) {
                    case "1":

                
                }

            }
        }
    }
}
