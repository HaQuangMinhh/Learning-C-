﻿namespace MIDTERM_MOCK_TEST_102
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var reader = new Reader();
            var num = reader.NextInt();

            var maxOdd = 0;
            for ( int i = 0; i <= num / 2; i++ ) {
                if ( num % i == 0 && i % 2 != 0 ) {
                    if (i > maxOdd) {
                        maxOdd = i; 
                    }
                }
            }

            Console.WriteLine( maxOdd );
        }
    }
    class Reader
    {
        private int index = 0;
        private string[] tokens;
        public string Next()
        {
            while (tokens == null || tokens.Length <= index)
            {
                tokens = Console.ReadLine().Split(new char[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
                index = 0;
            }
            return tokens[index++];
        }
        public int NextInt()
        {
            return int.Parse(Next());
        }

        public long NextLong()
        {
            return long.Parse(Next());
        }

        public double NextDouble()
        {
            return double.Parse(Next());
        }
    }
}
