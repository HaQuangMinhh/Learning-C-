﻿namespace _18_2_List
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var inputNum = int.Parse(Console.ReadLine()); 
            var binhPhuong = new List<int>();

            for (int i = 0; i < inputNum; i++) { 
                binhPhuong.Add(int.Parse(Console.ReadLine()));
            }

            // output
            Console.WriteLine();
            Console.WriteLine("List ban nhap la: ");
            for (int i = 0; i < binhPhuong.Count; i++) { 
                Console.Write(binhPhuong[i] + " ");
            }

            // create a new List 
            var binhPhuong2 = new List<double>(); // new 
           
            for (int i = 0; i < binhPhuong.Count; i++)
            {
                binhPhuong2.Add(Math.Pow(binhPhuong[i], 2));
            }
            Console.WriteLine() ;
            // output
            Console.WriteLine("List 2:") ;
            
            for (int i = 0; i < binhPhuong2.Count; i++)
            {
                Console.Write(binhPhuong2[i] + " ");
            }

            // xac dinh phan tu > 50 
            Console.WriteLine("phan tu > 50: ");
            int count = 0;
            for (int i = 0; i < binhPhuong2.Count; i++) {

                if (binhPhuong2[i] > 50) {
                    count++; 
                }
            }
            Console.WriteLine(count); 
        }
    }
}
