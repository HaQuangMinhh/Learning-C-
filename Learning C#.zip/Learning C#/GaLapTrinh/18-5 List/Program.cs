﻿namespace _18_5_List
{
    internal class Program
    {
        static void Main(string[] args)
        {

            var inputNum = int.Parse(Console.ReadLine()); 
            var List1 = new List<int>();

            for (int i = 0; i < inputNum; i++) { 
                List1.Add(int.Parse(Console.ReadLine()));
            }

            Console.WriteLine("Your output is: ");
            // output List
            for (int i = 0; i < List1.Count; i++) {
                Console.WriteLine($"Current index: {i}, name: {List1[i]}");
            }

            Console.WriteLine();
            Console.WriteLine($"Max Value is: {List1.Max()} ");

            // create a new List
            var List2 = new List<int>();

            List2.AddRange(List1);

            List2.Remove(List2.Max());
            List2.Remove(List2.Min());    

            Console.WriteLine("List2 is: ");
            for (int i = 0; i < List2.Count; i++) {
                Console.WriteLine($"Current index {i}, name: {List2[i]}");
            }

            //output ra phần tử > thứ 2 trong danh sách khi remove xong
            Console.WriteLine($"List 2 : big number : {List2.Max()}") ;

            //in ra vị trí index dùng
            for (int i = 0; i <= List1.Count; i++) {
                if (List1[i] == List2.Min() ) { 
                    Console.WriteLine($"index position of Min number: {i}") ;
                }
            }



        }
    }
}
