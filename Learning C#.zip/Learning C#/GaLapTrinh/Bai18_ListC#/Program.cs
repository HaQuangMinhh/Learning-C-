﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai18_ListC_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var ds1 = new List<string>(); 

            var ds2 = new List<int>() { 1,2,3,4,6 };

            foreach (int i in ds2) { 
                Console.Write(i + " ");
            }
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();

            var n = int.Parse(Console.ReadLine());
            var ds3 = new List<int>();

            for (int i = 0; i < n; i++) {
                ds3.Add(int.Parse(Console.ReadLine() ));
            }

            // show list C1
            for (int i = 0; i < ds3.Count; i++)
            {
                Console.WriteLine($"Current index {i},name: {ds3[i]} ");
            }

            //show List C2
            //foreach ( int i in ds3 ) {
            //    Console.Write(i + " "); 
            //}
            Console.WriteLine() ;
            

            // tạo ra 1 list bình phương 
            var ds4 = new List<double>();
            foreach (int i in ds3)
            {
                ds4.Add(Math.Pow(i,2));
            }

            Console.WriteLine("New List Binh phuong : ");
            //show List C2
            foreach (int i in ds4)
            {
                Console.Write(i + " "); 
            }
            Console.WriteLine();

            // xác định bao nhiêu phần tử lớn hơn 50 
            int dem = 0;

            foreach (int i in ds3) {
                if ( i > 50  ) {
                    dem++; 
                }
            }
            Console.WriteLine($"có {dem} phần tử > hơn 50 trong ds4");






        }
    }
}
