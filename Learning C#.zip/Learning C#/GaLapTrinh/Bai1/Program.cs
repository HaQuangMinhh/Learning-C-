﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var dtb = float.Parse(Console.ReadLine());

            if (dtb >= 8)
            {
                Console.WriteLine("Gioi");
            }
            else if (dtb >= 6.5)
            {
                Console.WriteLine("Kha");
            }
            else if (dtb >= 5)
            {
                Console.WriteLine("Trung Binh");
            } else 
            { 
                 Console.WriteLine("Yeu"); 
            }

        }
    }
}
