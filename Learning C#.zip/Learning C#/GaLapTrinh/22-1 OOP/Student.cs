﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _22_1_OOP
{
    public class Student
    {
        #region biến lớp 

        // khai báo 
        private int id;
        private string name;
        private double score; 

        #endregion

        // khai báo constructor do user truyền vào 
        public Student(int id, string name , double score) { 
            this.id = id;
            this.name = name;
            this.score = score;
        }

        // khai báo constructor cố định 
        public Student()
        {
            this.id = 0;
            this.name = "no name"; 
            this.score = 1 ;
        }
        // khai báo properties để truy xuất sửa đổi dữ liệu 
        public string Name
        {
            get { return name; } // get giá trị đọc
            set { name = value; } // set giá trị 
        }

        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        public double Score
        {
            get { return score; }
            set { score = value ; }
        }

        // phuong thuc ToString
        public override string ToString() { 
            return this.Id + "\t" + this.Name;
        }

        // support method 
        // kiem tra dieu kien nhap sinh vien moi 

        public bool CheckScore()
        {
            return (this.score - 21 >= 0);
        }

        // service method ( xuất thông tin ) 
        public void OutPut()
        {
            if (CheckScore() == false)
                Console.WriteLine("Can kiem tra lai ho so");
            else 
                Console.WriteLine(ToString());
        }




    }
}
