﻿namespace _22_1_OOP
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // create a person 
            //Student student1 = new Student();
            //Student student2 = new Student();

            //Console.WriteLine(student1.Id);
            //Console.WriteLine(student1.Name);

            // create a person khong truyen gia tri 
            Student student1 = new Student();
            Student student2 = new Student();

            //// create a person truyen gia tri 
            //Student student3 = new Student(3 , "Ha Quang Minh");
            //Console.WriteLine("Ten sinh vien 3 is: " + student3.Name);

            //// output 
            //Console.WriteLine(student1.Id);   // gọi properties
            //Console.WriteLine(student2.Id);

            //Console.WriteLine(student1.Name);
            //Console.WriteLine(student2.Name);


            
            //// phuong thuc ToString 
            //Console.WriteLine(student1.ToString());
            //Console.WriteLine(student2.ToString());
            //Console.WriteLine(student1);


            // Service Method && Support Method
            Student student3 = new Student(3 , "Ha Quang Minh" , 21);
            // check score 
            student3.OutPut();
            
            bool kq = student3.CheckScore();
            Console.WriteLine(kq);

            
        }
    }
}
